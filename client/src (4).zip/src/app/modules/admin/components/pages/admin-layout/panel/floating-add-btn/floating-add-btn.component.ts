import { Component } from '@angular/core';

@Component({
  selector: 'app-floating-add-btn',
  standalone: true,
  imports: [],
  templateUrl: './floating-add-btn.component.html',
  styleUrl: './floating-add-btn.component.css'
})
export class FloatingAddBtnComponent {

}
