import { Ticket } from "../tickets/ticket";

export interface Reservation {
    tickets: Ticket[];
    reservationFlag: string;
}
  