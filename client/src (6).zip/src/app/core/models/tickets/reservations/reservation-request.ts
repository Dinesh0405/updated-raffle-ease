export interface ReservationRequest {
    raffleId: number;
    ticketsIds: string[];
}
  