export interface GenerateRandomRequest {
    raffleId: number,
    quantity: number
}