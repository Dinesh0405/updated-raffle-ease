import { Component } from '@angular/core';

@Component({
  selector: 'app-raffle-description',
  standalone: true,
  imports: [],
  templateUrl: './raffle-description.component.html',
  styleUrl: './raffle-description.component.css'
})
export class RaffleDescriptionComponent {

}
