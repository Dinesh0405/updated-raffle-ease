export interface SearchRequest {
    raffleId: number,
    ticketNumber: string
}