import { Component } from '@angular/core';

@Component({
  selector: 'app-raffle-details',
  standalone: true,
  imports: [],
  templateUrl: './raffle-details.component.html',
  styleUrl: './raffle-details.component.css'
})
export class RaffleDetailsComponent {

}
