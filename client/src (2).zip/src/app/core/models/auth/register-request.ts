export interface RegisterRequest {
    name: string;
    email: string;
    phoneNumber: string;
    password: string;
    confirmPassword: string;
    city: string;
    zipCode: string;
  }
  