export interface AuthRequest {
    email: string;
    password: string;
}
