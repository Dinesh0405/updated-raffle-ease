export interface RaffleTicketsCreationRequest {
    amount: number;
    price: number;
    lowerLimit: number;
}
