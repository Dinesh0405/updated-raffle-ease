import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { FloatingAddBtnComponent } from './floating-add-btn/floating-add-btn.component';
import { RaffleCardComponent } from './raffle-card/raffle-card.component';
import { ShareRafflesService } from '../../../../../../core/services/raffles/share-raffles.service';
import { StatusCircleComponent } from '../../../shared/status-circle/status-circle.component';
import { ShareImagesService } from '../../../../../../core/services/raffles/share-images.service';
import { Raffle } from '../../../../../../core/models/raffles/raffle';

@Component({
  selector: 'app-panel',
  standalone: true,
  imports: [RouterLink, FloatingAddBtnComponent, RaffleCardComponent, StatusCircleComponent],
  templateUrl: './panel.component.html',
  styleUrl: './panel.component.css'
})
export class PanelComponent {
  constructor(
    private shareRaffles: ShareRafflesService,
    private shareImages: ShareImagesService
  ) { }

  raffles: Raffle[]=[ { id: 1, title: "Holiday Giveaway", description: "Enter to win fantastic holiday prizes!", startDate: new Date('2024-12-01'), endDate: '2024-12-25', status: 'ACTIVE', imageKeys: ['../assets/images/sample.png'], ticketPrice: 5, availableTickets: 1000, soldTickets: 200, totalTickets: 1200, revenue: 1000, associationId: 101 },{ id: 2, title: "Holiday Giveaway", description: "Enter to win fantastic holiday prizes!", startDate: new Date('2024-12-01'), endDate: '2024-12-25', status: 'ACTIVE', imageKeys: ['../assets/images/sample.png'], ticketPrice: 5, availableTickets: 1000, soldTickets: 200, totalTickets: 1200, revenue: 1000, associationId: 101}];
  images: Map<number, string[]>= new Map([ [1, ['../assets/images/sample.png']], [2, ['new_year_prizes.jpg', 'new_year_celebration.jpg']], [3, ['spring_festival.jpg', 'spring_flowers.jpg']] ]);

  getRaffles() {
    if (this.shareRaffles.isNull()) {
      this.shareRaffles.rafflesUpdates.subscribe({
        next: (raffles: Map<number, Raffle>) => {
          this.raffles = Array.from(raffles.values());
        }
      });
    } else {
      this.raffles = Array.from(this.shareRaffles.getAll().values());
    }
  }

  getImages() {
    if (this.shareImages.isNull()) {
      this.shareImages.imagesUpdates.subscribe({
        next: (images: Map<number, string[]>) => {
          this.images = images;
        }
      });
    } else {
      this.images = this.shareImages.getAll();
    }
  }

  ngOnInit() {
    this.getRaffles();
    this.getImages();
  }
}
